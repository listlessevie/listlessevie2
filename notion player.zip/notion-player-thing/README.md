# Notion Player Thing

A Pen created on CodePen.

Original URL: [https://codepen.io/pokcgpdv-the-flexboxer/pen/qEZezBy](https://codepen.io/pokcgpdv-the-flexboxer/pen/qEZezBy).

